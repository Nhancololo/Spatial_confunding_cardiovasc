# Simulation study and application: spatial confounding

Code for Section 8 (simulation) and the application of the paper
"When Should Spatial Confounding Be Adjusted? A Minimax Sensitivity
Analysis for Count Regression".

## Layout

    JoseBerilo.Rproj                  project root (read by `here`)
    data/Municipios_Brasil.RData      Brazilian municipalities
    script/functions.R                all functions: settings, graphs,
                                      geometry, fits, study, report,
                                      application, checks
    script/simulations.R              simulation study
    script/Real_data_application.R    Brazilian homicide data
    script/Data_mortality.R           deaths and expected deaths by cause,
                                      2022 (SIM-DO, Census 2022)
    script/Application_mortality.R    same application, mortality outcomes
    output/                           created by the scripts

## Use

Open `JoseBerilo.Rproj` or run the commands from any folder inside the
project. The `.Rproj` file marks the project root, so `here::here()` builds
every path and no `setwd()` is needed. Packages are installed and loaded with
`pacman::p_load` at the top of each script. INLA is not on CRAN; if it is
missing the scripts install it from `inla.r-inla-download.org`, and skip the
Bayesian fits if that fails.

    Rscript script/simulations.R check               # run first
    Rscript script/simulations.R pilot               # minutes
    Rscript script/simulations.R full                # the design of Section 8
    Rscript script/simulations.R full coverage,leakage   # selected experiments
    Rscript script/simulations.R pilot "" brazil     # adds coverage_brazil
    Rscript script/simulations.R report full         # redraw figures, tables
    Rscript script/Real_data_application.R Municipios_Brasil.RData \
        output/brazil complete FALSE TRUE

The mortality applications keep the nine covariates, the geometry and the
graph of the homicide application and change the outcome and the offset.
`Data_mortality.R` reads the SIM-DO deaths of 2022 by underlying cause and
municipality of residence (package `microdatasus`; non-fetal deaths, age in
years with 999 treated as ignored) and the Census 2022 population by sex and
five-year age group (IBGE SIDRA table 9514, package `sidrar`). For each cause
it computes the expected deaths by indirect standardisation, with national
rates by sex and age group, and writes

- `data/Mortality_2022.rds`, with `deaths_<key>`, `expected_<key>` and
  `pop_<key>` (population in the age range of the cause), the proportion of
  ill-defined causes `q_ill` (R00-R99 among all deaths with a municipality)
  and the proportion of selected nonspecific codes among circulatory deaths
  `q_nonspec` (the leading circulatory garbage codes of França et al., not
  the full classification; undefined where there are no circulatory deaths);
- `data/Mortality_audit.csv`, with the records of each cause that fall outside
  the municipalities, lack sex, or lack age only (exclusive categories that
  add up to the records minus those kept);
- `data/Base_municipal_2022.csv`, the municipal table of
  `Municipios_Brasil.RData` without geometry plus these columns.

`deaths_<key>` and `expected_<key>` use the records with known sex and age;
`deaths_all_raw` and `q_ill` use every record with a municipality, so
`deaths_ill_defined` is smaller than `q_ill` times `deaths_all_raw`.

Raw downloads are cached in `data/raw/`; a cached SIM file without `TIPOBITO`
is downloaded again. The script compares its total of deaths by municipality
with `obitos_p_residenc`.

| key | underlying cause (ICD-10) |
|---|---|
| `cvd` | circulatory system, I00-I99 |
| `cvd_premature` | I00-I99, ages 30-69 |
| `ihd` | ischaemic heart diseases, I20-I25 |
| `stroke` | cerebrovascular diseases, I60-I69 |
| `hypertensive` | hypertensive diseases, I10-I15 |
| `diabetes` | diabetes mellitus, E10-E14 |
| `neoplasm` | malignant neoplasms, C00-C97 |
| `homicide` | X85-Y09 and Y35-Y36 (the definition of `numero_de_homicidios`) |
| `ill_defined` | symptoms and ill-defined causes, R00-R99 |
| `all` | all causes |

`Application_mortality.R` is controlled by environment variables.

| variable | default | meaning |
|---|---|---|
| `outcome` | `cvd` | key of the table above (not `ill_defined`, `all`) |
| `exposure` | `tx_analfa` | covariate of the decision frontier and first row |
| `max_q` | `Inf` | keep municipalities with `q_ill` at most this value |
| `shapes` | `TRUE` | repeat the analysis for ICAR and BYM2 shapes |
| `require_inla` | `TRUE` | stop when INLA is missing instead of skipping it |

    Rscript script/Data_mortality.R                          # once
    Rscript script/Application_mortality.R                   # main analysis
    max_q=0.2 Rscript script/Application_mortality.R         # sensitivity
    outcome=cvd_premature Rscript script/Application_mortality.R

The output goes to `output/brazil_<key>/`, with the suffix `_q20` when
`max_q=0.2`. Besides the tables and figures of the homicide application it
holds `table_size` (counts by municipal population class),
`exposure_spectrum.csv` and `app_spectrum` (share of the squared norm of the
reduced exposure in the components with the largest prior variance) and
`covariate_units.csv` (mean and standard deviation of each covariate) and
`table_main` (rate ratios per five points of the main exposure when it is a
percentage), `table_vif` (variance inflation factors), the maps
`app_map_exposure` and `app_map_quality`, and `app_quality` (standardised
mortality ratio against the share of ill-defined causes). The sensitivity analysis uses the Poisson or negative binomial
family with the lower WAIC; the four families are compared only in
`table_waic` and `table_predictive`. The curves labelled BYM2 weights are
linear weights built from the BYM2 shape at the fitted scale, not the
posterior estimator of INLA, which `table_check` compares with them.
`Application_mortality.R` sources `Real_data_application.R`, so the arguments
below apply to both.

Arguments of `Real_data_application.R`, all optional and in this order: data
file, output directory, `impute`, `join`, `shapes`, `redraw`. A relative data path is searched
under the project root and its `data/` folder. `impute` is `complete` (drops municipalities with a missing
covariate), `global` or `spatial` (overall or neighbours' median). `join`
(`TRUE`) links each island to its nearest municipality. `shapes` (`TRUE`)
repeats the sensitivity analysis for ICAR and BYM2 shapes (slow).

Disconnected graphs keep their components. The intrinsic prior is scaled
component by component (isolated nodes carry no scale) and the component
indicators enter the controls. `cfg$brazil_join = TRUE` links each island
to its nearest unit instead. The no-confounding controls are the
`independent` family with c0 = 0 (no field), `independent` with c0 > 0
(smooth field drawn independently of x) and `orthogonal` (field with exact
zero sample correlation with the reduced exposure).

Confounder families (`fam` in the result files): `aligned`, `smooth`,
`band` (band-limited), `matern`, `local` (hotspot or region),
`independent`, `orthogonal` and `mixture` (smooth plus local).

Experiments (file `results_<name>.rds`): `gaussian_exact`,
`count_linearization`, `adjustment_cost`, `break_even`, `coverage`,
`coverage_nb`, `coverage_spatial_exposure` (exposure with no
non-spatial variation), `shape_misspecification`, `leakage`,
`estimated_radius`, `benchmark`, `coverage_brazil` and `timing`.

Methods in the result files: `NS` (non-spatial), `MM(c=...)` (minimax at a
fixed radius), `MM(c0)` (minimax at the true radius), `MM(sigma)` (radius
set to the fitted prior scale) and `MM(sigma)-no-bias` (the same estimate
with an interval that ignores the bias term).

Spatial+-ICAR in the simulation uses a low-rank spatial term (the
`splus_dim` smoothest eigenvectors); with the full basis the penalized
term absorbs part of the residual of x and the coefficient is biased even
without confounding. The INLA version in the application is full rank.

`output/<preset>/graphs.csv` lists, for each graph, n, the number of
components, isolated nodes, m = n - G and sqrt(m), to convert a radius c to
c / sqrt(m).

`count_linearization` runs the count analysis with the geometry at the
mean without the confounder ("baseline"); the suffixes `_true` and
`_fitted` use the true and the fitted mean. Poisson jobs use the
dispersion phi = 1 (strict Poisson); `_quasi` repeats the baseline run
with the Pearson estimate of phi (quasi-Poisson). The Brazilian analysis writes `sensitivity_cost.csv`
with the time and peak memory of each covariate.

The simulation stops at the first setting that fails, so a completed run
has no missing cells. Work is split into one task per setting of each job.
The true radius of every family is the realized radius of the field in the
fitted shape, which equals `c0` except for the `band`, `local` and `mixture` families. The Scottish graph has no coordinates: `matern` uses a planar
multidimensional-scaling embedding of its graph distances.

Results are stored per experiment in `output/<preset>/results_*.rds`;
figures (pdf and png) and tables (tex and csv) are written next to them.
Every setting draws its random numbers from a seed built from the global
seed, the design and the setting, so results do not depend on the number
of cores.

Packages (installed by `pacman`): Matrix, ggplot2, spdep, here (all runs);
sf, dplyr, ggspatial, scales, MASS (Brazil). INLA is not on CRAN and stays
optional: BYM2 fits in the application, reference fits in the
simulation when `cfg$use_inla` is set and the graph has a file).

The Scottish graph is read from INLA's `demodata/scotland.graph` unless
`cfg$scotland_graph` gives another file; without it, that graph is skipped.

`redraw` is `none` (default), `maps` (maps and effects figure) or
`sensitivity` (sensitivity tables, CSV files and figures); both read
`analysis_workspace.rds` of a finished run and do not refit the models.

`redraw = sensitivity` also writes `interval_length.csv`,
`tables/table_length.tex` and `figures/interval_length.pdf`: the radius of
the shortest bias-aware interval, its efficiency and that of the minimax
interval against the lower bound on the expected length of any confidence
set, at multiples of the reference radius.
